# 单词复习系统

📖 艾宾浩斯记忆曲线单词复习工具 - 支持翻卡、拼写、选择题多种模式

---

## 给最终用户（无需安装任何软件）

### Windows 用户

1. 解压收到的压缩包到一个文件夹
2. 双击 `start.bat`
3. 浏览器自动打开，直接使用

> 所有数据保存在浏览器本地，关闭窗口不丢失。

### 技术原理

使用 Windows 自带的 PowerShell + .NET `HttpListener` 启动本地服务器，不需要安装 Node.js、Python 或其他任何运行时。

---

## 给开发者

### 环境要求
- Node.js 18+
- npm

### 本地开发
```bash
npm install
npm run dev        # 启动开发服务器（热更新）
```

### 构建 + 启动（生产版）
```bash
npm run build      # 构建 dist/
npm run serve      # 启动本地服务（需要 Node.js）
```

### 打包分发
```bash
npm run build
```
然后把 `dist/` 文件夹 + `start.bat` 一起压缩包发给对方即可。
